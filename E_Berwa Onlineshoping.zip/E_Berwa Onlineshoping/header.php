﻿<header id="headerWrapper">
	<div id="header">
		<div id="logo">
			<a href="index-1.php"><img src="image/jewelleryshop.jpg" title="BB Jewellery Logo" alt="Our Logo" /></a>';
		</div>
		
		<div id="welcome"> Welcome visitor <a href="#" onClick="showLogin();">Login</a> or <a href="register.html">Sign Up</a>. </div>
		
		<div id="loginDiv" class="LoginDiv">
			
		</div>
		
	</div>
	<!-- Main Navigation Start-->            
	<?php include("navigation.php");?>
	<!-- Main Navigation End-->

	<div id="SearchDiv" class="SearchDiv">
			
	</div>

</header>
